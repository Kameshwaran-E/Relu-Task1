import React from "react";

interface NavItemProps {
  icon: string;
  text: string;
  active?: boolean;
}

const NavItem: React.FC<NavItemProps> = ({ icon, text, active = false }) => {
  return (
    <button
      className={`flex items-center p-3 text-gray-500 rounded-lg transition-all cursor-pointer duration-[0.2s] ${
        active ? "bg-gray-100" : ""
      }`}
    >
      <i className={`ti ti-${icon} mr-3 text-xl`} />
      <span className="text-sm max-md:hidden">{text}</span>
    </button>
  );
};

export default NavItem;
