
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { toast } from "react-toastify";
import NavItem from "./NavItem";

const Sidebar: React.FC = () => {
  const navItems = [
    { icon: "home", text: "Home", active: true },
    { icon: "bell", text: "Notifications" },
    { icon: "shopping-cart", text: "Shop" },
    { icon: "messages", text: "Conversation" },
    { icon: "wallet", text: "Wallet" },
    { icon: "star", text: "Subscription" },
    { icon: "user", text: "My Profile" },
    { icon: "settings", text: "Settings" },
  ];

  const { logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    try {
      await logout();
      toast.info("Logged out successfully");
      navigate("/login");
    } catch {
      toast.error("Failed to log out");
    }
  }

  return (
    <aside className="flex flex-col p-10 w-100 max-md:px-4 max-md:py-2 max-md:w-30">
      <h1 className="text-2xl font-semibold text-gray-900 max-md:text-xl bg-white items-center">
        LOGO
      </h1>

      <nav className="flex flex-col gap-3 mt-10 bg-white">
        {navItems.map((item, index) => (
          <NavItem key={index} icon={item.icon} text={item.text} active={item.active} />
        ))}
      </nav>

      <button
        onClick={handleLogout}
        className="flex items-center  text-gray-500 cursor-pointer mt-15 "
      >
        <i className="ti ti-logout mr-3 text-xl" />
        <span className="text-sm max-md:hidden">Log out</span>
      </button>
    </aside>
  );
};

export default Sidebar;
