import React from "react";

interface TabSelectorProps {
  tabs: string[];
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const TabSelector: React.FC<TabSelectorProps> = ({
  tabs,
  activeTab,
  onTabChange,
}) => {
  return (
    <nav className="flex gap-5 mb-6">
      {tabs.map((tab) => (
        <button
          key={tab}
          className={`pb-2 text-gray-500 border-b-2 border-solid cursor-pointer ${
            activeTab === tab
              ? "border-b-emerald-300 text-emerald-300"
              : "border-b-transparent"
          }`}
          onClick={() => onTabChange(tab)}
        >
          {tab}
        </button>
      ))}
    </nav>
  );
};

export default TabSelector;
