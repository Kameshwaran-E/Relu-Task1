import React from "react";

const SearchBar: React.FC = () => {
  return (
    <div className="flex grow items-center px-4 py-2 rounded-lg  max-sm:order-2 max-sm:w-full bg-white">
      <i className="ti ti-search mr-3 text-gray-500" />
      <input
        type="text"
        placeholder="Search here..."
        className="w-full text-sm border-[none] bg-transparent outline-none"
        aria-label="Search"
      />
      <button className="flex gap-2 items-center px-4 py-2 text-gray-500 rounded-lg  cursor-pointer max-sm:hidden">
          <i className="ti ti-adjustments" />
          <span>Filters</span>
        </button>
    </div>
  );
};

export default SearchBar;
