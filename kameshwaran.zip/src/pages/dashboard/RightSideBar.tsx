
import { useState } from "react";
import ArtistCard from "./ArtistCard";
import TabSelector from "./TabSelector";
import avatar1 from '../../assets/avatar1.webp'
import avatar2 from '../../assets/avatar2.webp'
import avatar3 from '../../assets/avatar3.webp'
import avatar4 from '../../assets/avatar4.webp'
import post3 from '../../assets/post3.webp'
import post4 from '../../assets/post4.webp'
import post5 from '../../assets/post5.webp'
import post6 from '../../assets/post6.webp'

const RightSidebar: React.FC = () => {
  const [activeTab, setActiveTab] = useState("Artists");

  const tabs = ["Artists", "Photographers"];

  const artists = [
    {
      id: 1,
      name: "Thomas Edward",
      handle: "@thewallwithyou",
      avatar: avatar1,
      banner: post3,
    },
    {
      id: 2,
      name: "Chris Doe",
      handle: "@thewallwithyou",
      avatar: avatar2,
      banner: post4,
    },
    {
      id: 3,
      name: "Emilie Jones",
      handle: "@thewallwithyou",
      avatar:  avatar3,
      banner: post5,
    },
    {
      id: 4,
      name: "Jessica Williams",
      handle: "@thewallwithyou",
      avatar: avatar4,
      banner: post6,
    },
  ];

  return (
    <aside className="w-[300px] max-md:w-[250px] max-sm:hidden ">
      <TabSelector
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      <div className="flex flex-col gap-4">
        {artists.map((artist) => (
          <ArtistCard key={artist.id} artist={artist} />
        ))}
      </div>
    </aside>
  );
};

export default RightSidebar;
