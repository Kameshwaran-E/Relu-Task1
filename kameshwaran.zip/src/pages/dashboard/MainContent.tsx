import React from "react";
import SearchBar from "./SearchBar";
import Post from "./Post";
import RightSidebar from "./RightSideBar";
import Lara from '../../assets/Lara.webp'
import thomas from '../../assets/thomas.png'
import post1 from '../../assets/post1.webp'
import post2 from '../../assets/post2.webp'

const MainContent: React.FC = () => {
  const posts = [
    {
      id: 1,
      user: {
        name: "Lara Leones",
        handle: "@thewallart",
        avatar: Lara,
      },
      content:
        "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
      image: post1,
      imageAlt: "Street art",
      stats: {
        likes: "9.8k",
        comments: "8.6k",
        shares: "7.2k",
      },
    },
    {
      id: 2,
      user: {
        name: "Thomas J.",
        handle: "@thecustomcreator",
        avatar: thomas,
      },
      content:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.",
    image: post2,
    imageAlt: "Street art",
    stats: {
      likes: "9.8k",
      comments: "8.6k",
      shares: "7.2k",
    },
    },
  ];

  return (
    <main className="grow p-5 max-sm:p-2.5">
      <header className="flex gap-5 items-center mb-8 max-sm:flex-wrap">
        <SearchBar />

        <button className="px-18 py-6 bg-[#88C2BB] rounded-lg cursor-pointer text-[white] max-sm:order-1 max-sm:w-full max-sm:text-center">
          Become a Seller
        </button>
      </header>

      <div className="flex gap-6">
        <section className="grow">
          {posts.map((post) => (
            <Post key={post.id} post={post} />
          ))}
        </section>

        <RightSidebar />
      </div>
    </main>
  );
};

export default MainContent;
