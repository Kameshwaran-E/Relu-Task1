import React from "react";

interface ArtistProps {
  artist: {
    name: string;
    handle: string;
    avatar: string;
    banner: string;
  };
}

const ArtistCard: React.FC<ArtistProps> = ({ artist }) => {
  const { name, handle, avatar, banner } = artist;

  return (
    <article className="overflow-hidden rounded-xl  relative">
  <div
    className="bg-center bg-cover h-[100px] relative"
    style={{ backgroundImage: `url('${banner}')` }}
    aria-hidden="true"
  >
    <div className="absolute bottom-2 left-3 flex items-center gap-2 bg-gray-50 rounded-lg px-4 py-2 ">
      <img src={avatar} alt="" className="w-10 h-10 rounded-lg border-2 border-white" />
      <div className="flex flex-col">
        <h3 className="font-medium ">{name}</h3>
        <h6 className="text-sm ">{handle}</h6>
      </div>
    </div>
  </div>
</article>

  

  );
};

export default ArtistCard;
