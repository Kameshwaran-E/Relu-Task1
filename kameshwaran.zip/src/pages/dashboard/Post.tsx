"use client";

import React from "react";

interface PostStats {
  likes: string;
  comments: string;
  shares: string;
}

interface PostUser {
  name: string;
  handle: string;
  avatar: string;
}

interface PostProps {
  post: {
    user: PostUser;
    content: string;
    image: string;
    imageAlt: string;
    stats: PostStats;
  };
}

const Post: React.FC<PostProps> = ({ post }) => {
  const { user, content, image, imageAlt, stats } = post;

  return (
    <article className="p-5 mb-5 rounded-xl max-sm:p-4 bg-white">
      <header className="flex justify-between items-center mb-4">
      <div className="flex gap-3 items-center">
  <img src={user.avatar} alt="" className="w-10 h-10 rounded-lg" />
  <div className="flex flex-col">
    <h3 className="font-medium text-gray-900">{user.name}</h3>
    <h6 className="text-sm text-gray-500">{user.handle}</h6>
  </div>
</div>

        <button aria-label="More options">
          <i className="ti ti-dots text-gray-500" />
        </button>
      </header>

      {content && (
        <div className="mb-4 text-sm text-gray-600">
          <span>{content}</span>
          {content.length > 100 && (
            <button className="ml-1 text-[#FF5E8A] cursor-pointer">
              Read More
            </button>
          )}
        </div>
      )}

      {image && (
        <div className="overflow-hidden mb-4 w-full rounded-xl">
          <img src={image} alt={imageAlt} className="w-full h-auto" />
        </div>
      )}

      {(stats.likes || stats.comments || stats.shares) && (
        <footer className="flex gap-6 max-sm:justify-around">
          <button className="flex gap-1.5 items-center text-sm text-gray-500">
            <i className="ti ti-heart" />
            <span>{stats.likes}</span>
          </button>
          <button className="flex gap-1.5 items-center text-sm text-gray-500">
            <i className="ti ti-message" />
            <span>{stats.comments}</span>
          </button>
          <button className="flex gap-1.5 items-center text-sm text-gray-500">
            <i className="ti ti-share" />
            <span>{stats.shares}</span>
          </button>
        </footer>
      )}
    </article>
  );
};

export default Post;
