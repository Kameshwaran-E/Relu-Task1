import Sidebar from "./SideBar";
import MainContent from "./MainContent";


const SocialDashboard: React.FC = () => {
  return (
    <>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <MainContent />
      </div>
    </>
  );
};

export default SocialDashboard;
