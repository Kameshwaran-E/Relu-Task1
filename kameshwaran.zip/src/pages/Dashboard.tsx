

import SocialDashboard from "./dashboard/SocialDashBoard";


// Main Dashboard Component
export const Dashboard: React.FC = () => {
  return (
    <>
     
        <SocialDashboard/>
     
    </>
  );
};

export default Dashboard;
